package com.camera.simplemjpeg;

/**
 * Created by Eduardo on 07-02-2015.
 */
final public class Constants {
    public static String IP_ADDRESS = "";
    public static final int PORT_NUM = 5001;
    public static final int PORT = 4953;
    public static final int PORT_TCP = 5000;
    public static final String STORAGE_FOLDER = "/storage/emulated/0/";


    private Constants(){

    }
}
